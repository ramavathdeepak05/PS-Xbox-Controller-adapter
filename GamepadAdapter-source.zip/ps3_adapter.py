#!/usr/bin/env python3
"""
Universal Gamepad to Keyboard Adapter
Supports PlayStation (PS3, PS4, PS5), Xbox (360, One, Series X/S), and Generic USB Controllers.
Zero external runtime dependencies: Built using native Windows APIs (XInput, WinMM, SendInput).
"""

import sys
import os

# Configure stdout/stderr encoding for Windows console compatibility
if sys.platform == 'win32':
    try:
        if sys.stdout is not None:
            sys.stdout.reconfigure(encoding='utf-8', errors='replace')
        if sys.stderr is not None:
            sys.stderr.reconfigure(encoding='utf-8', errors='replace')
    except Exception:
        pass

import json
import time
import threading
import ctypes
from ctypes import wintypes
import http.server
import socketserver
import webbrowser

try:
    import webview
except ImportError:
    webview = None

# --- Determine Base Path & UI Assets (Supports standalone PyInstaller .exe) ---
if getattr(sys, 'frozen', False):
    APP_DIR = os.path.dirname(sys.executable)
    if hasattr(sys, '_MEIPASS') and os.path.exists(os.path.join(sys._MEIPASS, "ui")):
        UI_DIR = os.path.join(sys._MEIPASS, "ui")
    else:
        UI_DIR = os.path.join(APP_DIR, "ui")
else:
    APP_DIR = os.path.dirname(os.path.abspath(__file__))
    UI_DIR = os.path.join(APP_DIR, "ui")

CONFIG_FILE = os.path.join(APP_DIR, "controller_mapping.json")
LEGACY_CONFIG = os.path.join(APP_DIR, "ps3_mapping.json")

# --- Native Windows Libraries ---
winmm = ctypes.windll.winmm
user32 = ctypes.windll.user32

# Load XInput (Xbox Controllers)
xinput_dll = None
for dll_name in ['xinput1_4.dll', 'xinput1_3.dll', 'xinput9_1_0.dll']:
    try:
        xinput_dll = ctypes.windll.LoadLibrary(dll_name)
        break
    except Exception:
        pass

# --- XInput Structures ---
class XINPUT_GAMEPAD(ctypes.Structure):
    _fields_ = [
        ('wButtons', wintypes.WORD),
        ('bLeftTrigger', ctypes.c_ubyte),
        ('bRightTrigger', ctypes.c_ubyte),
        ('sThumbLX', ctypes.c_short),
        ('sThumbLY', ctypes.c_short),
        ('sThumbRX', ctypes.c_short),
        ('sThumbRY', ctypes.c_short)
    ]

class XINPUT_STATE(ctypes.Structure):
    _fields_ = [
        ('dwPacketNumber', wintypes.DWORD),
        ('Gamepad', XINPUT_GAMEPAD)
    ]

# XInput Button Constants
XINPUT_GAMEPAD_DPAD_UP = 0x0001
XINPUT_GAMEPAD_DPAD_DOWN = 0x0002
XINPUT_GAMEPAD_DPAD_LEFT = 0x0004
XINPUT_GAMEPAD_DPAD_RIGHT = 0x0008
XINPUT_GAMEPAD_START = 0x0010
XINPUT_GAMEPAD_BACK = 0x0020
XINPUT_GAMEPAD_LEFT_THUMB = 0x0040
XINPUT_GAMEPAD_RIGHT_THUMB = 0x0080
XINPUT_GAMEPAD_LEFT_SHOULDER = 0x0100
XINPUT_GAMEPAD_RIGHT_SHOULDER = 0x0200
XINPUT_GAMEPAD_A = 0x1000
XINPUT_GAMEPAD_B = 0x2000
XINPUT_GAMEPAD_X = 0x4000
XINPUT_GAMEPAD_Y = 0x8000

# --- WinMM / DirectInput Structures (PlayStation & Generic USB Gamepads) ---
class JOYINFOEX(ctypes.Structure):
    _fields_ = [
        ('dwSize', wintypes.DWORD),
        ('dwFlags', wintypes.DWORD),
        ('dwXpos', wintypes.DWORD),
        ('dwYpos', wintypes.DWORD),
        ('dwZpos', wintypes.DWORD),
        ('dwRpos', wintypes.DWORD),
        ('dwUpos', wintypes.DWORD),
        ('dwVpos', wintypes.DWORD),
        ('dwButtons', wintypes.DWORD),
        ('dwButtonNumber', wintypes.DWORD),
        ('dwPOV', wintypes.DWORD),
        ('dwReserved1', wintypes.DWORD),
        ('dwReserved2', wintypes.DWORD)
    ]

class JOYCAPSW(ctypes.Structure):
    _fields_ = [
        ('wMid', wintypes.WORD),
        ('wPid', wintypes.WORD),
        ('szPname', wintypes.WCHAR * 32),
        ('wXmin', wintypes.UINT),
        ('wXmax', wintypes.UINT),
        ('wYmin', wintypes.UINT),
        ('wYmax', wintypes.UINT),
        ('wZmin', wintypes.UINT),
        ('wZmax', wintypes.UINT),
        ('wNumButtons', wintypes.UINT),
        ('wPeriodMin', wintypes.UINT),
        ('wPeriodMax', wintypes.UINT),
        ('wRmin', wintypes.UINT),
        ('wRmax', wintypes.UINT),
        ('wUmin', wintypes.UINT),
        ('wUmax', wintypes.UINT),
        ('wVmin', wintypes.UINT),
        ('wVmax', wintypes.UINT),
        ('wCaps', wintypes.UINT),
        ('wMaxAxes', wintypes.UINT),
        ('wNumAxes', wintypes.UINT),
        ('wMaxButtons', wintypes.UINT),
        ('szRegKey', wintypes.WCHAR * 32),
        ('szOEMVxD', wintypes.WCHAR * 260)
    ]

# --- Keyboard Input Structs for SendInput (Exact 40-byte 64-bit alignment) ---
INPUT_KEYBOARD = 1
KEYEVENTF_KEYUP = 0x0002
KEYEVENTF_SCANCODE = 0x0008
KEYEVENTF_EXTENDEDKEY = 0x0001

ULONG_PTR = ctypes.c_ulonglong if ctypes.sizeof(ctypes.c_void_p) == 8 else ctypes.c_ulong

class MOUSEINPUT(ctypes.Structure):
    _fields_ = [
        ('dx', wintypes.LONG),
        ('dy', wintypes.LONG),
        ('mouseData', wintypes.DWORD),
        ('dwFlags', wintypes.DWORD),
        ('time', wintypes.DWORD),
        ('dwExtraInfo', ULONG_PTR)
    ]

class KEYBDINPUT(ctypes.Structure):
    _fields_ = [
        ('wVk', wintypes.WORD),
        ('wScan', wintypes.WORD),
        ('dwFlags', wintypes.DWORD),
        ('time', wintypes.DWORD),
        ('dwExtraInfo', ULONG_PTR)
    ]

class HARDWAREINPUT(ctypes.Structure):
    _fields_ = [
        ('uMsg', wintypes.DWORD),
        ('wParamL', wintypes.WORD),
        ('wParamH', wintypes.WORD)
    ]

class INPUT(ctypes.Structure):
    class _INPUT(ctypes.Union):
        _fields_ = [
            ('mi', MOUSEINPUT),
            ('ki', KEYBDINPUT),
            ('hi', HARDWAREINPUT)
        ]
    _anonymous_ = ('_input',)
    _fields_ = [
        ('type', wintypes.DWORD),
        ('_input', _INPUT)
    ]

# Virtual Key Codes
VK_MAP = {
    'A': 0x41, 'B': 0x42, 'C': 0x43, 'D': 0x44, 'E': 0x45,
    'F': 0x46, 'G': 0x47, 'H': 0x48, 'I': 0x49, 'J': 0x4A,
    'K': 0x4B, 'L': 0x4C, 'M': 0x4D, 'N': 0x4E, 'O': 0x4F,
    'P': 0x50, 'Q': 0x51, 'R': 0x52, 'S': 0x53, 'T': 0x54,
    'U': 0x55, 'V': 0x56, 'W': 0x57, 'X': 0x58, 'Y': 0x59,
    'Z': 0x5A,
    '0': 0x30, '1': 0x31, '2': 0x32, '3': 0x33, '4': 0x34,
    '5': 0x35, '6': 0x36, '7': 0x37, '8': 0x38, '9': 0x39,
    'SPACE': 0x20, 'ENTER': 0x0D, 'RETURN': 0x0D, 'ESC': 0x1B,
    'ESCAPE': 0x1B, 'TAB': 0x09, 'SHIFT': 0x10, 'CTRL': 0x11,
    'ALT': 0x12, 'BACKSPACE': 0x08,
    'UP': 0x26, 'DOWN': 0x28, 'LEFT': 0x25, 'RIGHT': 0x27
}

EXTENDED_KEYS = {0x26, 0x28, 0x25, 0x27} # Up, Down, Left, Right arrow keys

def send_key_event(vk_code, is_down):
    """Sends a hardware scancode keyboard event via Windows SendInput for browser game compatibility."""
    if not vk_code:
        return
    scan = user32.MapVirtualKeyW(vk_code, 0)
    flags = KEYEVENTF_SCANCODE
    if not is_down:
        flags |= KEYEVENTF_KEYUP
    if vk_code in EXTENDED_KEYS:
        flags |= KEYEVENTF_EXTENDEDKEY

    inp = INPUT()
    inp.type = INPUT_KEYBOARD
    inp.ki.wVk = 0 # wVk must be 0 when using KEYEVENTF_SCANCODE
    inp.ki.wScan = scan
    inp.ki.dwFlags = flags
    inp.ki.time = 0
    inp.ki.dwExtraInfo = 0

    user32.SendInput(1, ctypes.byref(inp), ctypes.sizeof(INPUT))

MODIFIER_NAMES = ("CTRL", "ALT", "SHIFT")

def binding_key_names(key_str):
    """Split a binding such as 'CTRL+C' into known keys, modifiers first."""
    if not isinstance(key_str, str) or not key_str.strip():
        return []
    parts = []
    for raw in key_str.upper().split("+"):
        name = raw.strip()
        if name in VK_MAP and name not in parts:
            parts.append(name)
    mods = [name for name in MODIFIER_NAMES if name in parts]
    rest = [name for name in parts if name not in mods]
    return mods + rest

# Default game mapping (Optimized for fighting & arcade games)
DEFAULT_MAPPING = {
    # Movement
    "DPAD_UP": "W",          # Jump
    "DPAD_DOWN": "S",        # Crouch
    "DPAD_LEFT": "A",        # Move Left
    "DPAD_RIGHT": "D",       # Move Right
    "STICK_UP": "W",         # Analog Jump
    "STICK_DOWN": "S",       # Analog Crouch
    "STICK_LEFT": "A",       # Analog Move Left
    "STICK_RIGHT": "D",      # Analog Move Right
    "RSTICK_UP": "T",        # Right stick up -> Triangle
    "RSTICK_LEFT": "J",      # Right stick left -> Square
    "RSTICK_DOWN": "K",      # Right stick down -> Cross
    "RSTICK_RIGHT": "I",     # Right stick right -> Circle

    # Face Buttons
    "BUTTON_0": "J",         # Square [□] / Xbox X -> Punch
    "BUTTON_1": "K",         # Cross [X] / Xbox A -> Kick
    "BUTTON_2": "I",         # Circle [O] / Xbox B -> Grab
    "BUTTON_3": "T",         # Triangle [△] / Xbox Y -> Stage Select

    # Shoulder Buttons / Triggers
    "BUTTON_4": "M",         # L1 / LB -> Music
    "BUTTON_5": "L",         # R1 / RB -> Super
    "BUTTON_6": "SPACE",     # L2 / LT -> Super Alt / Space
    "BUTTON_7": "ENTER",     # R2 / RT -> Fight / Start Match

    # Center Buttons
    "BUTTON_8": "N",         # Select / Back / View -> Mute
    "BUTTON_9": "ESC",       # Start / Menu -> Pause Game

    # Stick Clicks
    "BUTTON_10": "1",        # L3 (Left Stick Click)
    "BUTTON_11": "2",        # R3 (Right Stick Click)
    "BUTTON_12": "",
    "BUTTON_13": ""
}

CONTROLLER_LABELS = {
    "STICK_UP": "Left Stick Up (Move / Jump)",
    "STICK_DOWN": "Left Stick Down (Crouch)",
    "STICK_LEFT": "Left Stick Left (Move Back)",
    "STICK_RIGHT": "Left Stick Right (Move Forward)",
    "RSTICK_UP": "Right Stick Up (Triangle / Y)",
    "RSTICK_LEFT": "Right Stick Left (Square / X)",
    "RSTICK_DOWN": "Right Stick Down (Cross / A)",
    "RSTICK_RIGHT": "Right Stick Right (Circle / B)",
    "DPAD_UP": "D-Pad Up (Jump)",
    "DPAD_DOWN": "D-Pad Down (Crouch)",
    "DPAD_LEFT": "D-Pad Left (Move Back/Block)",
    "DPAD_RIGHT": "D-Pad Right (Move Forward)",
    "BUTTON_0": "Square [□] / Xbox X (Punch)",
    "BUTTON_1": "Cross [X] / Xbox A (Kick)",
    "BUTTON_2": "Circle [O] / Xbox B (Grab)",
    "BUTTON_3": "Triangle [△] / Xbox Y (Stage)",
    "BUTTON_4": "L1 / LB (Target / Music)",
    "BUTTON_5": "R1 / RB (Super Attack)",
    "BUTTON_6": "L2 / LT (Super Alt)",
    "BUTTON_7": "R2 / RT (Fight / Enter)",
    "BUTTON_8": "Select / Back / View (Mute)",
    "BUTTON_9": "Start / Menu (Pause Combat)",
    "BUTTON_10": "L3 / Left Stick Click",
    "BUTTON_11": "R3 / Right Stick Click",
    "BUTTON_12": "PS / Guide Button",
    "BUTTON_13": "Button 13"
}


class UniversalControllerReader:
    """
    Seamlessly polls any connected controller:
    - Xbox 360, Xbox One, Xbox Series X/S via native Windows XInput.
    - PlayStation (PS3, PS4, PS5) and Generic USB gamepads via native Windows DirectInput (WinMM).
    """
    def __init__(self):
        self.mode = None # 'xinput' or 'winmm'
        self.active_id = 0
        self.device_name = "Detecting controller..."
        self.right_axes = ("dwZpos", "dwRpos")
        self._right_axes_id = None

        # WinMM Structures
        self.joy_info = JOYINFOEX()
        self.joy_info.dwSize = ctypes.sizeof(JOYINFOEX)
        self.joy_info.dwFlags = 0xFF # JOY_RETURNALL

        # XInput Structures
        self.xinput_state = XINPUT_STATE()

    def check_connection(self):
        # 1. Check XInput (Xbox Controllers, Ports 0-3)
        if xinput_dll is not None:
            for user_index in range(4):
                if xinput_dll.XInputGetState(user_index, ctypes.byref(self.xinput_state)) == 0:
                    self.mode = 'xinput'
                    self.active_id = user_index
                    self.device_name = f"Xbox / XInput Controller (Player {user_index + 1})"
                    return True

        # 2. Check WinMM (PlayStation & Generic USB Gamepads, Devices 0-15)
        num_devs = winmm.joyGetNumDevs()
        for dev_id in range(min(num_devs, 16)):
            if winmm.joyGetPosEx(dev_id, ctypes.byref(self.joy_info)) == 0:
                same_pad = self.mode == 'winmm' and self.active_id == dev_id and self._right_axes_id == dev_id
                self.mode = 'winmm'
                self.active_id = dev_id
                caps = JOYCAPSW()
                if winmm.joyGetDevCapsW(dev_id, ctypes.byref(caps), ctypes.sizeof(JOYCAPSW)) == 0 and caps.szPname:
                    name = caps.szPname.strip()
                    self.device_name = f"Gamepad: {name} (Device {dev_id})"
                else:
                    self.device_name = f"PlayStation / Generic Gamepad (Device {dev_id})"
                if not same_pad:
                    self._detect_right_axes()
                    self._right_axes_id = dev_id
                return True

        self.mode = None
        self._right_axes_id = None
        self.device_name = "Disconnected: Please plug in an Xbox, PlayStation, or USB controller"
        return False

    def _detect_right_axes(self):
        """Pick the two axes that rest at center. Triggers usually rest at an end."""
        centered = []
        for name in ("dwZpos", "dwRpos", "dwUpos", "dwVpos"):
            value = getattr(self.joy_info, name)
            if 12000 <= value <= 52000:
                centered.append(name)
        self.right_axes = tuple(centered[:2]) if len(centered) >= 2 else ("dwZpos", "dwRpos")

    def is_connected(self):
        return self.check_connection()

    def get_device_name(self):
        return self.device_name

    def get_family(self):
        """Which controller picture to show. XInput is Xbox; DirectInput names decide the rest."""
        name = (self.device_name or "").lower()
        if any(token in name for token in ("dualsense", "dualshock", "playstation", "sony", "ps5", "ps4", "ps3")):
            return "playstation"
        if any(token in name for token in ("xbox", "xinput", "x-box")):
            return "xbox"
        if self.mode == "xinput":
            return "xbox"
        return "playstation"

    def read_inputs(self, deadzone=14000):
        # Verify active connection
        if self.mode == 'xinput':
            if xinput_dll.XInputGetState(self.active_id, ctypes.byref(self.xinput_state)) != 0:
                if not self.check_connection():
                    return None
        elif self.mode == 'winmm':
            if winmm.joyGetPosEx(self.active_id, ctypes.byref(self.joy_info)) != 0:
                if not self.check_connection():
                    return None
        else:
            if not self.check_connection():
                return None

        active_inputs = set()

        # Handle Xbox / XInput Controllers
        if self.mode == 'xinput':
            gp = self.xinput_state.Gamepad
            btns = gp.wButtons

            # Face buttons
            if btns & XINPUT_GAMEPAD_X: active_inputs.add("BUTTON_0") # Square / X
            if btns & XINPUT_GAMEPAD_A: active_inputs.add("BUTTON_1") # Cross / A
            if btns & XINPUT_GAMEPAD_B: active_inputs.add("BUTTON_2") # Circle / B
            if btns & XINPUT_GAMEPAD_Y: active_inputs.add("BUTTON_3") # Triangle / Y

            # Bumpers & Triggers
            if btns & XINPUT_GAMEPAD_LEFT_SHOULDER: active_inputs.add("BUTTON_4")  # LB
            if btns & XINPUT_GAMEPAD_RIGHT_SHOULDER: active_inputs.add("BUTTON_5") # RB
            if gp.bLeftTrigger > 30: active_inputs.add("BUTTON_6")                 # LT
            if gp.bRightTrigger > 30: active_inputs.add("BUTTON_7")                # RT

            # Center Buttons
            if btns & XINPUT_GAMEPAD_BACK: active_inputs.add("BUTTON_8")  # View / Back
            if btns & XINPUT_GAMEPAD_START: active_inputs.add("BUTTON_9") # Menu / Start

            # Stick Clicks
            if btns & XINPUT_GAMEPAD_LEFT_THUMB: active_inputs.add("BUTTON_10")
            if btns & XINPUT_GAMEPAD_RIGHT_THUMB: active_inputs.add("BUTTON_11")

            # D-Pad
            if btns & XINPUT_GAMEPAD_DPAD_UP: active_inputs.add("DPAD_UP")
            if btns & XINPUT_GAMEPAD_DPAD_DOWN: active_inputs.add("DPAD_DOWN")
            if btns & XINPUT_GAMEPAD_DPAD_LEFT: active_inputs.add("DPAD_LEFT")
            if btns & XINPUT_GAMEPAD_DPAD_RIGHT: active_inputs.add("DPAD_RIGHT")

            # Left Analog Stick (XInput ranges -32768 to 32767; positive Y is UP)
            lx = gp.sThumbLX
            ly = gp.sThumbLY
            if lx < -deadzone: active_inputs.add("STICK_LEFT")
            elif lx > deadzone: active_inputs.add("STICK_RIGHT")

            if ly > deadzone: active_inputs.add("STICK_UP")
            elif ly < -deadzone: active_inputs.add("STICK_DOWN")

            rx = gp.sThumbRX
            ry = gp.sThumbRY
            if rx < -deadzone: active_inputs.add("RSTICK_LEFT")
            elif rx > deadzone: active_inputs.add("RSTICK_RIGHT")
            if ry > deadzone: active_inputs.add("RSTICK_UP")
            elif ry < -deadzone: active_inputs.add("RSTICK_DOWN")

            return active_inputs

        # Handle PlayStation & Generic USB Gamepads (WinMM)
        elif self.mode == 'winmm':
            # Buttons (bitmask)
            buttons = self.joy_info.dwButtons
            for b in range(14):
                if buttons & (1 << b):
                    active_inputs.add(f"BUTTON_{b}")

            # Left Stick (Centered at 32767; positive Y is DOWN)
            x = self.joy_info.dwXpos - 32767
            y = self.joy_info.dwYpos - 32767
            if x < -deadzone: active_inputs.add("STICK_LEFT")
            elif x > deadzone: active_inputs.add("STICK_RIGHT")

            if y < -deadzone: active_inputs.add("STICK_UP")
            elif y > deadzone: active_inputs.add("STICK_DOWN")

            rx = getattr(self.joy_info, self.right_axes[0]) - 32767
            ry = getattr(self.joy_info, self.right_axes[1]) - 32767
            if rx < -deadzone: active_inputs.add("RSTICK_LEFT")
            elif rx > deadzone: active_inputs.add("RSTICK_RIGHT")
            if ry < -deadzone: active_inputs.add("RSTICK_UP")
            elif ry > deadzone: active_inputs.add("RSTICK_DOWN")

            # D-Pad (dwPOV)
            pov = self.joy_info.dwPOV
            if pov != 65535:
                if pov in (31500, 0, 4500): active_inputs.add("DPAD_UP")
                if pov in (4500, 9000, 13500): active_inputs.add("DPAD_RIGHT")
                if pov in (13500, 18000, 22500): active_inputs.add("DPAD_DOWN")
                if pov in (22500, 27000, 31500): active_inputs.add("DPAD_LEFT")

            return active_inputs

        return None


class AdapterEngine:
    """Background engine translating gamepad inputs into hardware SendInput keystrokes."""
    def __init__(self, mapping):
        self.mapping = dict(mapping)
        self.reader = UniversalControllerReader()
        self.is_running = False
        self.is_active = True
        self.thread = None
        self.pressed_order = []
        self.current_active_inputs = set()
        self.lock = threading.Lock()

    def update_mapping(self, new_mapping):
        with self.lock:
            self.mapping = dict(new_mapping)

    def start(self):
        if self.is_running:
            return
        self.is_running = True
        self.thread = threading.Thread(target=self._loop, daemon=True)
        self.thread.start()

    def stop(self):
        self.is_running = False
        self._release_all()

    def _release_all(self):
        for vk in reversed(self.pressed_order):
            send_key_event(vk, False)
        self.pressed_order.clear()

    def _loop(self):
        while self.is_running:
            active_inputs = self.reader.read_inputs()
            if active_inputs is None:
                self._release_all()
                self.current_active_inputs = set()
                time.sleep(0.4)
                continue

            self.current_active_inputs = active_inputs

            if not self.is_active:
                self._release_all()
                time.sleep(0.005)
                continue

            names = []
            with self.lock:
                for inp in active_inputs:
                    names.extend(binding_key_names(self.mapping.get(inp, "")))

            desired = []
            seen = set()
            ordered_names = [name for name in MODIFIER_NAMES if name in names]
            for name in names:
                if name not in MODIFIER_NAMES and name not in ordered_names:
                    ordered_names.append(name)
            for name in ordered_names:
                vk = VK_MAP[name]
                if vk not in seen:
                    seen.add(vk)
                    desired.append(vk)

            modifier_vks = {VK_MAP[name] for name in MODIFIER_NAMES}
            releasing = [vk for vk in self.pressed_order if vk not in seen]
            releasing.sort(key=lambda vk: vk in modifier_vks)
            for vk in releasing:
                send_key_event(vk, False)
                self.pressed_order.remove(vk)

            for vk in desired:
                if vk not in self.pressed_order:
                    send_key_event(vk, True)
                    self.pressed_order.append(vk)

            time.sleep(0.001) # Ultra-fast 1ms polling rate for lag-free fighting game response


GLOBAL_ENGINE = None

class AdapterHTTPHandler(http.server.SimpleHTTPRequestHandler):
    extensions_map = http.server.SimpleHTTPRequestHandler.extensions_map.copy()
    extensions_map.update({
        '.js': 'text/javascript',
        '.mjs': 'text/javascript',
        '.gltf': 'model/gltf+json',
        '.bin': 'application/octet-stream'
    })
    
    def __init__(self, *args, **kwargs):
        super().__init__(*args, directory=UI_DIR, **kwargs)

    def log_message(self, format, *args):
        # Suppress noisy HTTP console logs
        pass

    def do_GET(self):
        global GLOBAL_ENGINE
        if self.path == '/api/mapping':
            self.send_response(200)
            self.send_header('Content-Type', 'application/json')
            self.end_headers()
            data = {
                "mapping": GLOBAL_ENGINE.mapping,
                "labels": CONTROLLER_LABELS
            }
            self.wfile.write(json.dumps(data).encode('utf-8'))
            return
        elif self.path == '/api/state':
            self.send_response(200)
            self.send_header('Content-Type', 'application/json')
            self.end_headers()
            data = {
                "connected": GLOBAL_ENGINE.reader.is_connected(),
                "device_name": GLOBAL_ENGINE.reader.get_device_name(),
                "family": GLOBAL_ENGINE.reader.get_family(),
                "active_inputs": list(GLOBAL_ENGINE.current_active_inputs),
                "is_active": GLOBAL_ENGINE.is_active
            }
            self.wfile.write(json.dumps(data).encode('utf-8'))
            return

        super().do_GET()

    def do_POST(self):
        global GLOBAL_ENGINE
        if self.path == '/api/toggle':
            GLOBAL_ENGINE.is_active = not GLOBAL_ENGINE.is_active
            self.send_response(200)
            self.send_header('Content-Type', 'application/json')
            self.end_headers()
            self.wfile.write(json.dumps({"is_active": GLOBAL_ENGINE.is_active}).encode('utf-8'))
            return
        elif self.path == '/api/save':
            length = int(self.headers.get('Content-Length', 0))
            body = self.rfile.read(length)
            new_mapping = json.loads(body.decode('utf-8'))
            GLOBAL_ENGINE.update_mapping(new_mapping)
            try:
                with open(CONFIG_FILE, 'w') as f:
                    json.dump(new_mapping, f, indent=4)
            except Exception:
                pass
            self.send_response(200)
            self.send_header('Content-Type', 'application/json')
            self.end_headers()
            self.wfile.write(b'{"status": "ok"}')
            return
        elif self.path == '/api/reset':
            GLOBAL_ENGINE.update_mapping(DEFAULT_MAPPING)
            try:
                with open(CONFIG_FILE, 'w') as f:
                    json.dump(DEFAULT_MAPPING, f, indent=4)
            except Exception:
                pass
            self.send_response(200)
            self.send_header('Content-Type', 'application/json')
            self.end_headers()
            self.wfile.write(json.dumps({"mapping": DEFAULT_MAPPING}).encode('utf-8'))
            return

        self.send_response(404)
        self.end_headers()


def load_saved_mapping():
    for path in [CONFIG_FILE, LEGACY_CONFIG]:
        if os.path.exists(path):
            try:
                with open(path, "r") as f:
                    data = json.load(f)
                    res = dict(DEFAULT_MAPPING)
                    res.update(data)
                    return res
            except Exception:
                pass
    return dict(DEFAULT_MAPPING)


def run_cli():
    """Headless CLI mode for lightweight or background usage."""
    mapping = load_saved_mapping()
    engine = AdapterEngine(mapping)
    print("=" * 65)
    print("[*] Universal Gamepad to Keyboard Adapter (CLI Mode)")
    print("Supports: Xbox (One / Series / 360), PlayStation (PS3 / PS4 / PS5)")
    print("=" * 65)
    if engine.reader.is_connected():
        print(f"Status: Connected ({engine.reader.get_device_name()})")
    else:
        print("Status: Waiting for controller to connect...")

    print("\nActive Mappings:")
    for inp, key in mapping.items():
        if key:
            label = CONTROLLER_LABELS.get(inp, inp)
            print(f"  {label:<38} -> [{key}]")

    print("\nAdapter running! Press Ctrl+C in this console to exit.")
    engine.start()
    try:
        while True:
            time.sleep(1)
    except KeyboardInterrupt:
        print("\nStopping adapter...")
        engine.stop()
        print("Adapter stopped.")


def run_web_gui(port=8080):
    """Launches the Liquid Glass UI in a standalone desktop window via pywebview."""
    global GLOBAL_ENGINE
    mapping = load_saved_mapping()
    GLOBAL_ENGINE = AdapterEngine(mapping)
    GLOBAL_ENGINE.start()

    server = None
    for p in range(port, port + 20):
        try:
            server = socketserver.TCPServer(("127.0.0.1", p), AdapterHTTPHandler)
            port = p
            break
        except OSError:
            continue

    if not server:
        print("[ERROR] Could not find an open port for the Web UI.")
        return

    # Start the HTTP server on a daemon thread
    server_thread = threading.Thread(target=server.serve_forever, daemon=True)
    server_thread.start()

    url = f"http://127.0.0.1:{port}/"
    print("=" * 65)
    print("[*] Universal Gamepad Adapter (Desktop Application)")
    print(f"Internal API running at: {url}")
    print("=" * 65)

    try:
        import webview
        # Open in a dedicated native desktop window
        webview.create_window(
            title="Controller Mapping",
            url=url,
            width=1440,
            height=900,
            resizable=True,
            min_size=(1100, 720)
        )
        webview.start()
    except ImportError:
        print("[INFO] pywebview not detected. Opening in browser as fallback...")
        threading.Timer(0.6, lambda: webbrowser.open(url)).start()
        try:
            while True:
                time.sleep(1)
        except KeyboardInterrupt:
            pass
    finally:
        print("\nShutting down adapter...")
        GLOBAL_ENGINE.stop()
        server.shutdown()
        print("Adapter stopped.")


if __name__ == "__main__":
    if "--cli" in sys.argv:
        run_cli()
    else:
        run_web_gui()
